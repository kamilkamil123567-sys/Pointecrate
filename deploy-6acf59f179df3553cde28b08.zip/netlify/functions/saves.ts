import type { Config, Context } from "@netlify/functions";
import { desc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { listSaves, siteContent } from "../../db/schema.js";

const isAdmin = (req: Request) => {
  // Set ADMIN_PASSWORD in Netlify env vars to override the default
  const expected = process.env.ADMIN_PASSWORD || "Kacpronowice12345";
  return Boolean(expected) && req.headers.get("x-admin-password") === expected;
};

export default async (req: Request, context: Context) => {
  const id = context.params.id ? Number(context.params.id) : null;
  if (context.params.id && !Number.isInteger(id)) return new Response("Not found", { status: 404 });

  if (req.method === "GET") {
    // Single save with its full list data
    if (id !== null) {
      const [row] = await db.select().from(listSaves).where(eq(listSaves.id, id));
      if (!row) return new Response("Not found", { status: 404 });
      return Response.json(row, { headers: { "cache-control": "no-store" } });
    }
    // List of saves (without data)
    const rows = await db
      .select({ id: listSaves.id, name: listSaves.name, createdAt: listSaves.createdAt })
      .from(listSaves)
      .orderBy(desc(listSaves.createdAt));
    return Response.json(rows, { headers: { "cache-control": "no-store" } });
  }

  if (!isAdmin(req)) return new Response("Unauthorized", { status: 401 });

  if (req.method === "POST" && id === null) {
    const body = await req.json().catch(() => null);
    const name = String(body?.name ?? "").trim().slice(0, 100);
    if (!name) return new Response("Name required", { status: 400 });

    // Snapshot the current main list as stored on the server
    const [current] = await db.select().from(siteContent).where(eq(siteContent.id, "main"));
    if (!current) return new Response("Main list is empty", { status: 400 });

    const [row] = await db
      .insert(listSaves)
      .values({ name, data: current.data })
      .returning({ id: listSaves.id, name: listSaves.name, createdAt: listSaves.createdAt });
    return Response.json(row, { status: 201 });
  }

  if (req.method === "DELETE" && id !== null) {
    await db.delete(listSaves).where(eq(listSaves.id, id));
    return Response.json({ ok: true });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: ["/api/saves", "/api/saves/:id"],
};

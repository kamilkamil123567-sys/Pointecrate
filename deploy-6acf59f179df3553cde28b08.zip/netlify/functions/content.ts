import type { Config } from "@netlify/functions";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { siteContent } from "../../db/schema.js";

const ROW_ID = "main";

const isAdmin = (req: Request) => {
  // Set ADMIN_PASSWORD in Netlify env vars to override the default
  const expected = process.env.ADMIN_PASSWORD || "Kacpronowice12345";
  return Boolean(expected) && req.headers.get("x-admin-password") === expected;
};

export default async (req: Request) => {
  const url = new URL(req.url);

  // Password check for the login prompt
  if (url.pathname.endsWith("/login") && req.method === "POST") {
    return isAdmin(req)
      ? Response.json({ ok: true })
      : Response.json({ ok: false }, { status: 401 });
  }

  if (req.method === "GET") {
    const [row] = await db.select().from(siteContent).where(eq(siteContent.id, ROW_ID));
    return Response.json(row ? row.data : null, {
      headers: { "cache-control": "no-store" },
    });
  }

  if (req.method === "PUT") {
    if (!isAdmin(req)) return new Response("Unauthorized", { status: 401 });

    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object" || !Array.isArray(body.levels) || !Array.isArray(body.players)) {
      return new Response("Invalid content", { status: 400 });
    }

    const data = {
      siteTitle: String(body.siteTitle ?? ""),
      footerText: String(body.footerText ?? ""),
      levels: body.levels,
      players: body.players,
    };

    await db
      .insert(siteContent)
      .values({ id: ROW_ID, data, updatedAt: new Date() })
      .onConflictDoUpdate({ target: siteContent.id, set: { data, updatedAt: new Date() } });

    return Response.json({ ok: true });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: ["/api/content", "/api/login"],
};

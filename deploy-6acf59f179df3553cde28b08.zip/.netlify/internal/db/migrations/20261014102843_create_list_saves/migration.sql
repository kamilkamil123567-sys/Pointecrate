CREATE TABLE "list_saves" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"data" jsonb NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

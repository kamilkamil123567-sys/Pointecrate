import { pgTable, text, jsonb, timestamp, serial } from "drizzle-orm/pg-core";

// Single-row store for the whole editable site content (levels, players, texts)
export const siteContent = pgTable("site_content", {
  id: text().primaryKey(),
  data: jsonb().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Named snapshots of the main list, created by the admin and visible to everyone
export const listSaves = pgTable("list_saves", {
  id: serial().primaryKey(),
  name: text().notNull(),
  data: jsonb().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
